/**
 * VAULT1 — SHARED THEME
 * ---------------------------------------------------------
 * One source of truth for colors, fonts and glass tokens.
 * Import this into every screen instead of redefining
 * constants locally — that's what keeps the whole app in
 * sync when you tweak a shade later.
 *
 * Usage:
 *   import { COLORS, FONT, GLASS } from "../theme";
 */

import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  Inter_800ExtraBold,
  Inter_900Black,
} from "@expo-google-fonts/inter";

/* ========================================================= */
/* COLOR SYSTEM                                                */
/* ========================================================= */

export const COLORS = {
  bull: "#0FBE7A", // teal-green — gains / primary brand
  bear: "#E5455C", // red — losses
  accentBlue: "#3B82F6", // electric blue — secondary glow

  navyDeep: "#080D18",
  navyMid: "#0E1626",
  navyLine: "#1D2A44",

  ink: "#F8FAFC",
  muted: "#8592A6",

  glassBg: "rgba(17,26,46,0.55)",
  glassBgSoft: "rgba(255,255,255,0.035)",
  glassBorder: "rgba(255,255,255,0.09)",
  glowTeal: "rgba(15,190,122,0.45)",
  glowBlue: "rgba(59,130,246,0.35)",
};

/* ========================================================= */
/* FONT SYSTEM — Inter, everywhere                             */
/* ========================================================= */

export const FONT = {
  regular: "Inter_400Regular",
  medium: "Inter_500Medium",
  semiBold: "Inter_600SemiBold",
  bold: "Inter_700Bold",
  extraBold: "Inter_800ExtraBold",
  black: "Inter_900Black",
};

/**
 * Call this ONCE per screen (or once globally in your root
 * layout — see note at the bottom of this file) before
 * rendering. Returns `true` once Inter is ready.
 */
export function useAppFonts() {
  const [loaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
    Inter_800ExtraBold,
    Inter_900Black,
  });
  return loaded;
}

/* ========================================================= */
/* GLASS / MOTION TOKENS — reused by GlassCard, buttons, etc.  */
/* ========================================================= */

export const GLASS = {
  cardRadius: 18,
  ringGlowOpacityPrimary: 0.55,
  ringGlowOpacitySecondary: 0.28,
  breathDuration: 3400,
  ringSpinDurationPrimary: 9000,
  ringSpinDurationSecondary: 14000,
  shimmerDuration: 1600,
  shimmerPause: 2200,
};

/**
 * BEST PRACTICE: rather than calling useAppFonts() in every
 * single screen (which re-checks the font cache on every
 * navigation), load fonts ONCE in your root layout
 * (app/_layout.tsx) and gate the whole app behind it, e.g.:
 *
 *   const fontsLoaded = useAppFonts();
 *   if (!fontsLoaded) return null; // or a splash screen
 *   return <Slot />;
 *
 * Then every inner screen can assume Inter is already
 * available and skip the loading check entirely.
 */
